﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace System_04._08_ex4;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}
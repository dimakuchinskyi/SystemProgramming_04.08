﻿using System.Windows;

namespace System_ex2
{
    public partial class App : Application
    {
    }
}
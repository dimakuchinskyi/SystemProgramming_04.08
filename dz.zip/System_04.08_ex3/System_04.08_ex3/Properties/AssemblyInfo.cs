﻿namespace System_04._08_ex3.Properties;

public class AssemblyInfo
{
    
}
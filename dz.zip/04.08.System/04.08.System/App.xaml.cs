﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _04._08.System;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}
﻿// ChildProcess/Program.cs
using System;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length != 3)
        {
            Console.WriteLine("Потрібно 3 аргументи: число1 число2 операція(+-*/)");
            return;
        }
        
        double a = double.Parse(args[0]);
        double b = double.Parse(args[1]);
        string op = args[2];

        Console.WriteLine($"Результат: {a} {op} {b} = {Calculate(a, b, op)}");
    }

    static double Calculate(double x, double y, string op) => op switch
    {
        "+" => x + y,
        "-" => x - y,
        "*" => x * y,
        "/" => x / y,
        _ => throw new ArgumentException("Невідома операція")
    };
}
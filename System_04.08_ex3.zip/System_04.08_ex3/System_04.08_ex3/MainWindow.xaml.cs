﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows;

namespace System_04._08_ex3
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
{
    try
    {
        string firstNumber = FirstNumberTextBox.Text;
        string secondNumber = SecondNumberTextBox.Text;
        string operation = OperationTextBox.Text;

        if (string.IsNullOrWhiteSpace(firstNumber) ||
            string.IsNullOrWhiteSpace(secondNumber) ||
            string.IsNullOrWhiteSpace(operation))
        {
            MessageBox.Show("Please fill all fields", "Error",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }
        
        string childProcessPath = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory,
            @"C:\Users\dima\RiderProjects\System_04.08_ex3\ChildProcess\bin\Debug\net8.0\ChildProcess.exe");
        
        if (!File.Exists(childProcessPath))
        {
            MessageBox.Show($"Child process not found at path:\n{childProcessPath}", "Error",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }
        else
        {
            MessageBox.Show($"Child process found at path:\n{childProcessPath}", "Info",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        
        if (!File.Exists(childProcessPath))
        {
            MessageBox.Show($"Child process not found at path:\n{childProcessPath}", "Error",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        ProcessStartInfo startInfo = new ProcessStartInfo
        {
            FileName = childProcessPath,
            Arguments = $"{firstNumber} {secondNumber} {operation}",
            UseShellExecute = false,
            RedirectStandardOutput = true,
            CreateNoWindow = false,
            WorkingDirectory = Path.GetDirectoryName(childProcessPath)
        };

        using (Process process = new Process { StartInfo = startInfo })
        {
            process.Start();
            string output = process.StandardOutput.ReadToEnd();
            process.WaitForExit();

            MessageBox.Show($"Child process output:\n{output}", "Result",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Error: {ex.Message}", "Error",
            MessageBoxButton.OK, MessageBoxImage.Error);
    }
}
    }
}